<?php $__env->startSection('title', 'Users > Query Form'); ?>
<?php $__env->startSection('page_heading'); ?>
    <section class="content-header">
        <h3 class="pull-left">
            Query Form
        </h3>
        <ul class="breadcrumb pull-right">
           
            <li><a href="<?php echo e(route('customers.complains_view')); ?>">Query Form</a></li>
            <li class="active"> Query Form</li>
        </ul>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('section'); ?>
    <div class="row">
        <div class="col-sm-12">
            <?php echo Form::open([
                    'route' => 'customers.submit_query',
                    'method' => 'post',
                    'role' => 'form',
                    'class' => 'form-vertical',
                    
                ]);
                 csrf_field(); ?>

            <div class="panel panel-default">
                <div class="panel-heading font-bold"> &nbsp;</div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="name "><?php echo e(__('Name')); ?><span class="required">*</span></label>
                                <?php echo Form::text('name', null, array('required' => true, 'class' => 'form-control')); ?>

                              </div>
                        </div>
                       <div class="col-sm-3">
                            <div class="form-group">
                                <label for="email "><?php echo e(__('Email')); ?><span class="required">*</span></label>
                                <?php echo Form::text('email', null, array('required' => true, 'class' => 'form-control')); ?>

                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-8">
                            <div class="form-group">
                                <label for="message"><?php echo e(__('Message')); ?><span class="required">*</span></label>
                              <?php echo Form::textarea('message', null, array('required' => true, 'class' => 'form-control')); ?>

                            </div>
                        </div>
                       </div> 
                    <div class="line line-dashed b-b line-lg "></div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <input type="submit" value="<?php echo e(__('Submit')); ?>" class="btn green btn-primary btn-flat button">
                                <button class="btn btn-default btn-flat" name="button" type="reset">
                                    <?php echo e(__('Reset')); ?>

                                </button>
                                <a class="btn btn-danger btn-flat" href="<?php echo e(route('users.index')); ?>">
                                    <i class="fa fa-times"></i> <?php echo e(__('Cancel')); ?>

                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\myprojects\registration\resources\views/customer/query_form.blade.php ENDPATH**/ ?>