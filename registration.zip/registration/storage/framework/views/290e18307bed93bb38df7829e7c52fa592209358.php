<?php $__env->startSection('section'); ?>

      <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-md-6">
                        </div>
                        <div class="col-md-6">
                            <div class="btn-group pull-right">
                                <a class="btn green btn-success btn-flat"
                                   href="<?php echo e(route('customers.query')); ?>"
                                   title="Add new Complaint"><i class="fa fa-plus"></i> New Complaint</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel-body">
                    <table class="responsive table table-hover table-condensed order-column">
                        <thead>
                        <tr class="">
                           <th>Name</th>
                            <th>Email</th>
                            <th>Message</th>
                        </tr>
                            <?php $__currentLoopData = $customerCompalian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                 <tr class="">
                                    <td><?php echo e($data->name); ?></td>
                                    <td><?php echo e($data->email); ?></td>
                                    <td><?php echo e($data->message); ?></td>
                                 </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>; 
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\myprojects\registration\resources\views/customer/customer_complain_view.blade.php ENDPATH**/ ?>