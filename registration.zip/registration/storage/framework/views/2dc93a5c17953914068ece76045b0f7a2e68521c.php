<?php $__env->startSection('title', 'Users > Profile'); ?>
<?php $__env->startSection('page_heading'); ?>

      <section class="content-header">
        <h1 class="pull-left">
            <?php echo e(__('Profile')); ?>

        </h1>
        <ul class="breadcrumb pull-right">
           
            <li><a href="<?php echo e(route('users.index')); ?>">Users</a></li>
            
        </ul>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('section'); ?>
<div class="row">
        <div class="col-sm-12">
    <?php echo Form::open(['route' => ['users.update', $user->id], 'method' => 'post','id' => 'form_settings','role'=>'form',
   'class'=>'form-vertical']); ?>

     <div class="panel panel-default">
                <div class="panel-heading font-bold"> &nbsp;</div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="name "><?php echo e(__('Name')); ?><span class="required">*</span></label>
                                <?php echo Form::text('name', $user->name, array('required' => true, 'class' => 'form-control')); ?>

                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="phone "><?php echo e(__('Phone')); ?><span class="required">*</span></label>
                                <?php echo Form::text('phone', $user->phone, array('required' => true,'class' => 'form-control')); ?>

                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="country_id "><?php echo e(__('Country')); ?><span class="required">*</span></label>
                                 <?php echo Form::select('country_id',  $countriesDropDownList, $user->country_id, array('required' => true, 'class' => 'form-control user', 'id' => 'country_id' )); ?>

                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="state_id"><?php echo e(__('State')); ?><span class="required">*</span></label>
                                      <?php echo Form::select('state_id',  $StateDropDownList, $user->state_id, array('required' => true, 'class' => 'form-control user', 'id' => 'state_id')); ?>

                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="email "><?php echo e(__('Email')); ?></label>
                                <?php echo Form::text('email', $user->email, array('required' => false, 'class' => 'form-control')); ?>

                            </div>
                        </div>
                       </div> 
                    <div class="line line-dashed b-b line-lg "></div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <input type="submit" value="<?php echo e(__('Update')); ?>" class="btn green btn-primary btn-flat button">
                                <button class="btn btn-default btn-flat" name="button" type="reset">
                                    <?php echo e(__('Reset')); ?>

                                </button>
                                <a class="btn btn-danger btn-flat" href="<?php echo e(route('users.index')); ?>">
                                    <i class="fa fa-times"></i> <?php echo e(__('Cancel')); ?>

                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    <?php echo Form::close(); ?>

 </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\myprojects\registration\resources\views/admin/profile.blade.php ENDPATH**/ ?>