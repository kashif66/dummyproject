<?php $__env->startSection('section'); ?>

      <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-md-6">
                        </div>
                        <div class="col-md-6">
                            <div class="btn-group pull-right">
                                <a class="btn green btn-success btn-flat"
                                   href="<?php echo e(route('users.add')); ?>"
                                   title="Add new User"><i class="fa fa-plus"></i> New User</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel-body">
                    <table class="responsive table table-hover table-condensed order-column">
                        <thead>
                        <tr class="">
                            <th>#</th>
                            <th>Name</th>
                            <th>Country</th>
                            <th>State</th>
                            <th>Phone</th>
                            <th>Email</th>
                            <th>Created At</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('last_scripts'); ?>

    <script type="text/javascript">
        $(document).ready(function () {
            $('table').DataTable({
                ajax: '<?php echo e(route('users.data')); ?>',
                columns: [
                    {data: 'id', name: 'id', searchable: false},
                    {data: 'name', name: 'name'},
                    {data: 'country_name', name: 'country_name'},
                    {data: 'state_name', name: 'state_name'},
                    {data: 'phone', name: 'phone'},
                    {data: 'email', name: 'email'},
                    {data: 'created_at', name: 'created_at', searchable: false},
                    {data: 'actions', name: 'actions', orderable: false, searchable: false}
                ]
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\myprojects\registration\resources\views/admin/index.blade.php ENDPATH**/ ?>