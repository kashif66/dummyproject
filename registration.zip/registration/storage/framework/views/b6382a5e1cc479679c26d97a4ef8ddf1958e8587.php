<?php $__env->startSection('title', 'Customer '); ?>
<?php $__env->startSection('page_heading'); ?>
    <section class="content-header">
        <h1 class="pull-left">
             Customer
        </h1>
        <ul class="breadcrumb pull-right">
           <li class="active">Customer</li>
        </ul>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('section'); ?>

      <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-md-6">
                        </div>
                        <div class="col-md-6">
                            <div class="btn-group pull-right">
                              
                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel-body">
                    <table class="responsive table table-hover table-condensed order-column">
                        <thead>
                        <tr class="">
                           
                            <th>Name</th>
                            <th>Country</th>
                            <th>State</th>
                            <th>Phone</th>
                            <th>Email</th>
                           <th>Actions</th>
                        </tr>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->country->name); ?></td>
                            <td><?php echo e($user->state->name); ?></td>
                            <td><?php echo e($user->phone); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td> <a href= "<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-info" >Update</a>
                                <a href= "<?php echo e(route('users.changePassword', $user->id)); ?>" class="btn btn-primary" >ChangePassword</a></td>
                           
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\myprojects\registration\resources\views/customer/index.blade.php ENDPATH**/ ?>