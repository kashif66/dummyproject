<div class="navbar-default sidebar" role="navigation">
    <div class="sidebar-nav navbar-collapse">
        <ul class="nav" id="side-menu">
            <?php if(Auth::user()->roles == "Admin"): ?>
            <li <?php echo e((Request::is('*users') ? 'class=active' : '')); ?>>
                <a href="<?php echo e(route('users.index')); ?>"><i class="fa fa-home fa-fw"></i> Dashboard</a>
            </li>
             <li <?php echo e((Request::is('*complains') ? 'class=active' : '')); ?>>
                <a href="<?php echo e(route('customers.complains')); ?>"><i class="fa fa-home fa-fw"></i> Customer Complains</a>
            </li>
             <?php endif; ?>
            <?php if(Auth::user()->roles == "Customer"): ?>
             <li <?php echo e((Request::is('*users') ? 'class=active' : '')); ?>>
                <a href="<?php echo e(route('customers.profile')); ?>"><i class="fa fa-home fa-fw"></i> Dashboard</a>
            </li>
            	 <li <?php echo e((Request::is('*customer') ? 'class=active' : '')); ?>>
                <a href="<?php echo e(route('customers.complains_view')); ?>"><i class="fa fa-home fa-fw"></i> Query Form</a>
            </li>
            <?php endif; ?>
          
            
        </ul>
    </div>
    <!-- /.sidebar-collapse -->
</div>
<!-- /.navbar-static-side -->
<?php /**PATH E:\myprojects\registration\resources\views/admin/partials/sidebar.blade.php ENDPATH**/ ?>