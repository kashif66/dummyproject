<!DOCTYPE html>
<html>
<head>
    <title>Welcome Email</title>
</head>

<body>
<h2>Welcome to the site <?php echo e($user['name']); ?></h2>
<br/>
Your registered email-id is <?php echo e($user['email']); ?>

</body>

</html><?php /**PATH E:\myprojects\registration\resources\views/emails/welcome.blade.php ENDPATH**/ ?>