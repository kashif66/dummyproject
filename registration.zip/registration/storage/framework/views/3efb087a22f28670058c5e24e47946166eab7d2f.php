<?php $__env->startSection('title', 'Users > Add User'); ?>
<?php $__env->startSection('page_heading'); ?>
    <section class="content-header">
        <h1 class="pull-left">
             Add User
        </h1>
        <ul class="breadcrumb pull-right">
           
            <li><a href="<?php echo e(route('users.index')); ?>">Users</a></li>
            <li class="active">Add User</li>
        </ul>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('section'); ?>
    <div class="row">
        <div class="col-sm-12">
            <?php echo Form::open([
                    'route' => 'users.store',
                    'method' => 'post',
                    'role' => 'form',
                    'class' => 'form-vertical',
                    
                ]);
                 csrf_field(); ?>

            <div class="panel panel-default">
                <div class="panel-heading font-bold"> &nbsp;</div>
                <div class="panel-body">
                  <div class="row">
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="name "><?php echo e(__('Name')); ?><span class="required">*</span></label>
                              <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                              <input type="hidden" name="roles" value="Customer">
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="phone "><?php echo e(__('Phone')); ?><span class="required">*</span></label>
                               <input id="phone" type="tel" class="form-control" name="phone" value="<?php echo e(old('phone')); ?>" required autocomplete="phone" autofocus>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="country_id "><?php echo e(__('Country')); ?><span class="required">*</span></label>
                                 <Select id="country_id" class="form-control" name="country_id" autofocus> 
                                    <?php $__currentLoopData = $countriesDropDownList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>"> <?php echo e($value); ?></option> 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </Select>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="state_id"><?php echo e(__('State')); ?><span class="required">*</span></label>
                                      <Select id="state_id" class="form-control" name="state_id" autofocus>
                                     <?php $__currentLoopData = $StateDropDownList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option id="state_id" value="<?php echo e($key); ?>"> <?php echo e($value); ?></option> 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </Select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="email "><?php echo e(__('Email')); ?></label>
                                <?php echo Form::text('email', null, array('required' => false, 'class' => 'form-control')); ?>

                            </div>
                        </div>
                            <div class="col-sm-3">
                            <div class="form-group">
                                <label for="email "><?php echo e(__('Password')); ?></label>
                                   <input id="password" type="password" class="form-control" name="password" required autocomplete="new-password">
                            </div>
                        </div>
                            <div class="col-sm-3">
                            <div class="form-group">
                                <label for="email "><?php echo e(__('Confirm Password')); ?></label>
                               <input id="password-confirm" type="password" class="form-control" name="confirm_password" required autocomplete="new-password">
                            </div>
                        </div>
                        </div>
                    </div>
                    <div class="line line-dashed b-b line-lg "></div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <input type="submit" value="<?php echo e(__('Save')); ?>" class="btn green btn-primary btn-flat button">
                                <button class="btn btn-default btn-flat" name="button" type="reset">
                                    <?php echo e(__('Reset')); ?>

                                </button>
                                <a class="btn btn-danger btn-flat" href="<?php echo e(route('users.index')); ?>" >
                                    <i class="fa fa-times"></i> <?php echo e(__('Cancel')); ?></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('last_scripts'); ?>
<script type="text/javascript">
var states_token = '<?php echo e(csrf_token()); ?>';
var states_url = "<?php echo e(route('get_states')); ?>";
</script>
<script src="<?php echo e(asset('auth_assets/get-states.js')); ?>"></script>
<script type="text/javascript">
    $(document).ready(function(){
        $("#country_id").change(function(){
            var country_id =$(this).val();
            var states_token = '<?php echo e(csrf_token()); ?>';
            $.ajax({
                url: '<?php echo e(route("get_phonecode")); ?>',
               method:"POST",
               data:{country_id:country_id, _token:states_token},
               dataType:"json",
               success:function(data){
                   console.log(data);
                    $('#phone_code').val(data.phone_code);
                 
               }
                
          });
        });
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\myprojects\registration\resources\views/admin/add.blade.php ENDPATH**/ ?>