<div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
    </button>
    <a class="navbar-brand" href="<?php echo e(url ('')); ?>">Dummy-Project</a>
</div>
<!-- /.navbar-header -->

<ul class="nav navbar-top-links navbar-right">
    <li class="dropdown">

        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
            <span class="hidden-sm hidden-md"><?php echo e(Auth::user()->name); ?></span>
            <i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
        </a>
        <ul class="dropdown-menu dropdown-user">
            <li><a href="<?php echo e(route('users.profile')); ?>"><i class="fa fa-user fa-fw"></i> User Profile</a>
            </li>
          
            <li class="divider"></li>
              <?php if(Auth::user()->roles == "Admin"): ?>
            <li><a href="<?php echo e(route('users.changePassword', Auth::user()->id )); ?>"><i class="fa fa-user fa-fw"></i> Edit Password</a>
            </li>
            <li class="divider"></li>
            <?php endif; ?>

            <li> <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
            </li>
            
        </ul>
        <!-- /.dropdown-user -->
    </li>
    <!-- /.dropdown -->
</ul>
<!-- /.navbar-top-links --><?php /**PATH E:\myprojects\registration\resources\views/admin/partials/topbar.blade.php ENDPATH**/ ?>