<?php $__env->startSection('title', 'Users > Edit User'); ?>
<?php $__env->startSection('page_heading'); ?>
    <section class="content-header">
        <h1 class="pull-left">
            Change password
        </h1>
        <ul class="breadcrumb pull-right">
            
            <li class="active">Change password</li>
        </ul>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('section'); ?>
    <div class="row">
        <div class="col-sm-12">
            <?php echo Form::open([
                'route' => 'users.savePassword',
                'method' => 'post',
                'id' => 'form_settings',
                'class'=>'form-vertical',
               
            ]); ?>

            <div class="panel panel-default">
                <div class="panel-heading font-bold"> &nbsp;</div>
                <div class="panel-body">
                    
           
            <div class="row">

                <div class="col-sm-4">
                    <div class="form-group">
                        <label for="password"><?php echo e(__('Password')); ?><span
                                class="required">*</span></label>
                            <input required class="form-control" id="password" placeholder="<?php echo e(__('Please enter password')); ?>" name="old_password" type="password" value="<?php echo e(old('old_password')); ?>">
                                    
                    </div>
                </div>
            </div>
            <div class="row">

                <div class="col-sm-4">
                    <div class="form-group">
                        <label for="password"><?php echo e(__('New Password')); ?><span
                                class="required">*</span></label>
                        <input required class="form-control" id="password" placeholder="<?php echo e(__('Please enter password')); ?>"
                               name="password" type="password" value="<?php echo e(old('password')); ?>">
                               <input name="id" type="hidden" value="<?php echo e($id); ?>">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-4">
                    <div class="form-group">
                        <label for="confirm_password"><?php echo e(__('Confirm Password')); ?><span
                                class="required">*</span></label>
                        <input required class="form-control" placeholder="<?php echo e(__('Please enter password')); ?>"
                               name="confirm_password" type="password" value="<?php echo e(old('confirm_password')); ?>">
                    </div>
                </div>
            </div>
            <div class="line line-dashed b-b line-lg "></div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group">
                        <input type="submit" value="<?php echo e(__('Save')); ?>" class="btn green btn-primary btn-flat button">
                        <button class="btn btn-default btn-flat" name="button" type="reset">
                            <?php echo e(__('Reset')); ?>

                        </button>
                        <a class="btn btn-danger btn-flat"
                           href="<?php echo e(route('users.index')); ?>">
                            <i class="fa fa-times"></i> <?php echo e(__('Cancel')); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\myprojects\registration\resources\views/admin/change_password.blade.php ENDPATH**/ ?>