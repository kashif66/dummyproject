<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// login
Auth::routes();

// ajax 
Route::post('get-states', 'AuthController@getStates')->name('get_states');
Route::post('get-phone-code', 'AuthController@getCode')->name('get_phonecode');
Route::get('/home', 'HomeController@index')->name('home');

// users
Route::group(['middleware' => 'admin', 'prefix' => 'admin'], function () {
Route::get('users', 'UserController@index')->name('users.index');
Route::get('users/add', 'UserController@create')->name('users.add');
Route::get('users/data', 'UserController@data')->name('users.data');
});

Route::post('users/store', 'UserController@store')->name('users.store');
Route::get('users/{id}/edit', 'UserController@edit')->name('users.edit');
Route::post('users/edit/{id}', 'UserController@update')->name('users.update');
Route::get('users/destroy/{id}', 'UserController@destroy')->name('users.destroy');
Route::get('users/profile', 'UserController@profile')->name('users.profile');
Route::post('users/edit', 'UserController@profile_update')->name('users.profile_update');
Route::get('users/change-password/{id}', 'UserController@changePassword')->name('users.changePassword');
Route::post('users/change-password', 'UserController@savePassword')->name('users.savePassword');

// customer
Route::get('customers/complaints', 'CustomerController@index')->name('customers.complains');
Route::get('customers/query', 'CustomerController@create')->name('customers.query');
Route::get('customers/profile', 'CustomerController@profile')->name('customers.profile');
Route::get('customers/complaints-view', 'CustomerController@customerComplain')->name('customers.complains_view');
Route::post('customers/submit-query', 'CustomerController@store')->name('customers.submit_query');
Route::get('customers-complains/destroy/{id}', 'CustomerController@destroy')->name('complains.destroy');
