function showTwilioDiv()
{
	if($('#is_twilio_notification').is(":checked")){
		$('#twilio_div').show();
	}else{
		$('#twilio_div').hide();
	}
}

function showEmailDiv()
{
	if($('#is_email_notification').is(":checked")){
		$('#email_div').show();
	}else{
		$('#email_div').hide();
	}
}

$(document).ready(function () 
{
	/* var stringVal = '<label id="myLabel" for="protein" >Muzammil</label>';
	var inputVal = $(stringVal).filter("[for='protein']").text();
	alert(inputVal);
	labelText = $("[for='protein']").text();
	alert(labelText)*/
	showEmailDiv();
	showTwilioDiv();
});