$(document).ready(function () {
    $('.target_slug').slugify('.source_slug');
    $('.datepicker').datepicker({
        orientation: 'bottom',
        format: 'DD, M d, yyyy'
    });

	$('.start_date').datepicker({
        autoclose: true,
        format: 'DD, M d, yyyy'
    }).on('changeDate', function(e) {
        $('.end_date').datepicker('setStartDate', $('.start_date').datepicker('getDate'));
    });
    $('.end_date').datepicker({
        autoclose: true,
        format: 'DD, M d, yyyy'
    }).on('changeDate', function(e) {
        $('.start_date').datepicker('setEndDate', $('.end_date').datepicker('getDate'));
    });

    // Admin-Menu
    var $itemCategorySelect = $('#item-category-select');
    if ($itemCategorySelect.length > 0) {
        $itemCategorySelect.select2({ containerCssClass: 'select2-eplatform' });
    }

    var $itemPageSelect = $('#item-page-select');
    if ($itemPageSelect.length > 0) {
        $itemPageSelect.select2({ containerCssClass: 'select2-eplatform' });
    }
});

$.extend(true, $.fn.dataTable.defaults, {
    lengthMenu: [
        [15, 25, 50],
        [15, 25, 50]
    ],
    pageLength: 15,
    pagingType: "full_numbers",
    processing: true,
    serverSide: true
});
