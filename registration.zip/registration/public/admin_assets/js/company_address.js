
        jQuery(document).ready(function () {
            // get states
            jQuery("#country_id").on("change", function() {
                jQuery('#state_id').html("");
                countyId = jQuery(this).val();
               
                jQuery.post( states_url,{ countyId: countyId, _token:states_token }, function( data ) {
                    jQuery.each(data.country_states, function(key, value){
                        jQuery('#state_id').append('<option value="' + key + '" >' + value + '</option>');
                    })
                    //to load cities
                    jQuery("#state_id").trigger("change");
                }, "json" );
                
               
            });

            // get cities
            jQuery("#state_id").on("change", function() {
                jQuery('#city_id').html("");
                stateId = jQuery(this).val();
                
                jQuery.post( cities_url,{ stateId: stateId, _token:cities_token }, function( data ) {
                    jQuery.each(data.state_cities, function(key, value){
                        jQuery('#city_id').append('<option value="' + key + '" >' + value + '</option>');
                    })
                }, "json" );
               
            });
        });
