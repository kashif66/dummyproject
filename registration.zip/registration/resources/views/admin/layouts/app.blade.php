@extends('admin.layouts.plane')
@section('body')
    <div id="wrapper">
        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            @include('admin.partials.topbar')
            @include('admin.partials.sidebar')
        </nav>

        <div id="page-wrapper">
            <div class="error-messages">
               @include('flash::message')
                @include('flash.message')
            </div>
            <br>
            @yield('page_heading')
            @yield('section')
        </div>
    </div>
@endsection

