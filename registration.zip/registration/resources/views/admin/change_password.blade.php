@extends('admin.layouts.app')
@section('title', 'Users > Edit User')
@section('page_heading')
    <section class="content-header">
        <h1 class="pull-left">
            Change password
        </h1>
        <ul class="breadcrumb pull-right">
            
            <li class="active">Change password</li>
        </ul>
    </section>
@endsection
@section('section')
    <div class="row">
        <div class="col-sm-12">
            {!! Form::open([
                'route' => 'users.savePassword',
                'method' => 'post',
                'id' => 'form_settings',
                'class'=>'form-vertical',
               
            ]) !!}
            <div class="panel panel-default">
                <div class="panel-heading font-bold"> &nbsp;</div>
                <div class="panel-body">
                    
           
            <div class="row">

                <div class="col-sm-4">
                    <div class="form-group">
                        <label for="password">{{ __('Password') }}<span
                                class="required">*</span></label>
                            <input required class="form-control" id="password" placeholder="{{ __('Please enter password') }}" name="old_password" type="password" value="{{ old('old_password') }}">
                                    
                    </div>
                </div>
            </div>
            <div class="row">

                <div class="col-sm-4">
                    <div class="form-group">
                        <label for="password">{{ __('New Password') }}<span
                                class="required">*</span></label>
                        <input required class="form-control" id="password" placeholder="{{ __('Please enter password') }}"
                               name="password" type="password" value="{{ old('password') }}">
                               <input name="id" type="hidden" value="{{ $id }}">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-4">
                    <div class="form-group">
                        <label for="confirm_password">{{ __('Confirm Password') }}<span
                                class="required">*</span></label>
                        <input required class="form-control" placeholder="{{ __('Please enter password') }}"
                               name="confirm_password" type="password" value="{{ old('confirm_password') }}">
                    </div>
                </div>
            </div>
            <div class="line line-dashed b-b line-lg "></div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group">
                        <input type="submit" value="{{ __('Save') }}" class="btn green btn-primary btn-flat button">
                        <button class="btn btn-default btn-flat" name="button" type="reset">
                            {{ __('Reset') }}
                        </button>
                        <a class="btn btn-danger btn-flat"
                           href="{{ route('users.index') }}">
                            <i class="fa fa-times"></i> {{ __('Cancel') }}</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {!! Form::close()  !!}

@stop
