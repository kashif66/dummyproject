<div class="navbar-default sidebar" role="navigation">
    <div class="sidebar-nav navbar-collapse">
        <ul class="nav" id="side-menu">
            @if(Auth::user()->roles == "Admin")
            <li {{ (Request::is('*users') ? 'class=active' : '') }}>
                <a href="{{ route('users.index') }}"><i class="fa fa-home fa-fw"></i> Dashboard</a>
            </li>
             <li {{ (Request::is('*complains') ? 'class=active' : '') }}>
                <a href="{{ route('customers.complains') }}"><i class="fa fa-home fa-fw"></i> Customer Complains</a>
            </li>
             @endif
            @if(Auth::user()->roles == "Customer")
             <li {{ (Request::is('*users') ? 'class=active' : '') }}>
                <a href="{{ route('customers.profile') }}"><i class="fa fa-home fa-fw"></i> Dashboard</a>
            </li>
            	 <li {{ (Request::is('*customer') ? 'class=active' : '') }}>
                <a href="{{ route('customers.complains_view') }}"><i class="fa fa-home fa-fw"></i> Query Form</a>
            </li>
            @endif
          
            
        </ul>
    </div>
    <!-- /.sidebar-collapse -->
</div>
<!-- /.navbar-static-side -->
