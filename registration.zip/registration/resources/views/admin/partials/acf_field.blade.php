<div class="form-group">
    @if(!isset($option['repeater']))
    <label>{{$option['label']}}</label>
    @endif
    @if ($option['type'] == 'text')
          <input value="{{ $value}}" name="{{ $field_name}}"  type="{{ $option['type'] }}" class="form-control" >
    @elseif ($option['type'] == 'textarea')
         <textarea  name="{{ $field_name}}" class="form-control" rows="5" >{{ $value }}</textarea>
    @elseif (in_array($option['type'],['image','file']))
        <input  name="{{ $field_name }}"  type="hidden"  value="{{ $value }}" >
        <input  name="{{ $field_name }}"  type="file" accept="image/*"  >
        @if($value != '')
            <img src="{{ s3Path().$value }}" alt="" style="max-height: 100px; max-width: 100px;"  />
        @endif
    @elseif ($option['type'] == 'select')
        <select  name="{{ $field_name }}" class="form-control">
            @if (isset($option['choices']))
                @foreach ($option['choices'] as $key => $choice)
                    <option value="{{ $key }}" @if ($key == $value) selected @endif >{{ $choice }}</option>
                @endforeach
            @endif
        </select>
    @else
        <input value="{{ $value }}" name="{{ $field_name }}"  type="{{ $option['type'] }}" class="form-control" >
    @endif
</div>