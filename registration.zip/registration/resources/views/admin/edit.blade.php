@extends('admin.layouts.app')
@section('title', 'Users > Edit User')
@section('page_heading')
    <section class="content-header">
        <h3 class="pull-left">
            Edit User
        </h3>
       
    </section>
@endsection
@section('section')
    <div class="row">
        <div class="col-sm-12">
            {!!
                Form::model($user, [
                    'route' => ['users.update', $user->id],
                    'method' => 'post',
                    'role' => 'form',
                    'class' => 'form-vertical',
                    'enctype' => "multipart/form-data"
                ])
           !!}
            <div class="panel panel-default">
                <div class="panel-heading font-bold"> &nbsp;</div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="name ">{{ __('Name') }}<span class="required">*</span></label>
                                {!! Form::text('name', $user->name, array('required' => true, 'class' => 'form-control')) !!}
                                {{ Form::hidden('roles', 'Customer') }}
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="phone ">{{ __('Phone') }}<span class="required">*</span></label>
                                {!! Form::text('phone', null, array('required' => true,'class' => 'form-control')) !!}
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="country_id ">{{ __('Country') }}<span class="required">*</span></label>
                                 {!! Form::select('country_id',  $countriesDropDownList, $user->country_id, array('required' => true, 'class' => 'form-control user', 'id' => 'country_id' )) !!}
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="state_id">{{ __('State') }}<span class="required">*</span></label>
                                      {!! Form::select('state_id',  $StateDropDownList, $user->state_id, array('required' => true, 'class' => 'form-control user', 'id' => 'state_id')) !!}
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="email ">{{ __('Email') }}</label>
                                {!! Form::text('email', null, array('required' => false, 'class' => 'form-control')) !!}
                            </div>
                        </div>
                       </div> 
                    <div class="line line-dashed b-b line-lg "></div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <input type="submit" value="{{ __('Update') }}" class="btn green btn-primary btn-flat button">
                                <button class="btn btn-default btn-flat" name="button" type="reset">
                                    {{ __('Reset') }}
                                </button>
                                <a class="btn btn-danger btn-flat" href="{{ route('users.index') }}">
                                    <i class="fa fa-times"></i> {{ __('Cancel') }}
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {!! Form::close()  !!}
        </div>
    </div>
@endsection
@section('last_scripts')
<script type="text/javascript">
var states_token = '{{ csrf_token() }}';
var states_url = "{{ route('get_states') }}";
</script>
<script src="{{ asset('auth_assets/get-states.js') }}"></script>
<script type="text/javascript">
    $(document).ready(function(){
        $("#country_id").change(function(){
            var country_id =$(this).val();
            var states_token = '{{ csrf_token() }}';
            $.ajax({
                url: '{{ route("get_phonecode") }}',
               method:"POST",
               data:{country_id:country_id, _token:states_token},
               dataType:"json",
               success:function(data){
                   console.log(data);
                    $('#phone_code').val(data.phone_code);
                 
               }
                
          });
        });
    })
</script>
@stop