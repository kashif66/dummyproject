@extends('admin.layouts.app')
@section('title', 'Users > Profile')
@section('page_heading')

      <section class="content-header">
        <h1 class="pull-left">
            {{ __('Profile') }}
        </h1>
        <ul class="breadcrumb pull-right">
           
            <li><a href="{{ route('users.index') }}">Users</a></li>
            
        </ul>
    </section>
@endsection

@section('section')
<div class="row">
        <div class="col-sm-12">
    {!! Form::open(['route' => ['users.update', $user->id], 'method' => 'post','id' => 'form_settings','role'=>'form',
   'class'=>'form-vertical']) !!}
     <div class="panel panel-default">
                <div class="panel-heading font-bold"> &nbsp;</div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="name ">{{ __('Name') }}<span class="required">*</span></label>
                                {!! Form::text('name', $user->name, array('required' => true, 'class' => 'form-control')) !!}
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="phone ">{{ __('Phone') }}<span class="required">*</span></label>
                                {!! Form::text('phone', $user->phone, array('required' => true,'class' => 'form-control')) !!}
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="country_id ">{{ __('Country') }}<span class="required">*</span></label>
                                 {!! Form::select('country_id',  $countriesDropDownList, $user->country_id, array('required' => true, 'class' => 'form-control user', 'id' => 'country_id' )) !!}
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="state_id">{{ __('State') }}<span class="required">*</span></label>
                                      {!! Form::select('state_id',  $StateDropDownList, $user->state_id, array('required' => true, 'class' => 'form-control user', 'id' => 'state_id')) !!}
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="email ">{{ __('Email') }}</label>
                                {!! Form::text('email', $user->email, array('required' => false, 'class' => 'form-control')) !!}
                            </div>
                        </div>
                       </div> 
                    <div class="line line-dashed b-b line-lg "></div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <input type="submit" value="{{ __('Update') }}" class="btn green btn-primary btn-flat button">
                                <button class="btn btn-default btn-flat" name="button" type="reset">
                                    {{ __('Reset') }}
                                </button>
                                <a class="btn btn-danger btn-flat" href="{{ route('users.index') }}">
                                    <i class="fa fa-times"></i> {{ __('Cancel') }}
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    {!! Form::close()  !!}
 </div>
    </div>
@endsection
