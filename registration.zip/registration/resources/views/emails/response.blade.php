<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional //EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html style="margin: 0;padding: 0;" xmlns="http://www.w3.org/1999/xhtml"><!--<![endif]-->
<head>

	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta name="viewport" content="width=device-width">
	<!--[if !mso]><!-->
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<!--<![endif]-->
	<title>Email</title>
	<div>
	 @if(isset($firstName))	<b>First Name:</b>  {{$firstName}} @endif
	</div>
	<div>
	@if(isset($lastName)) <b>Last Name:</b>  {{ $lastName}}  @endif
	</div>
	<div>
	@if(isset($messageBody))	<b>Message:</b>  {{$messageBody}}  @endif
	</div>
	



</body>
</html>



