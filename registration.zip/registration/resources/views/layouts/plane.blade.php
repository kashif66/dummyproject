<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en" class="no-js">
<!--<![endif]-->
<head>
	<meta charset="utf-8"/>
	<title>@yield('title')</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1" name="viewport">
	<?php $asset_path =   asset().'/'; ?>
    <link rel="stylesheet" href="{{$asset_path}}css/bootstrap.css" type="text/css" />
	<link rel="stylesheet" href="{{$asset_path}}css/bootstrap-datepicker.min.css" type="text/css" />
    <link rel="stylesheet" href="{{$asset_path}}css/dataTables.bootstrap.min.css" type="text/css" />
	<link rel="stylesheet" href="{{$asset_path}}css/font-awesome.css" type="text/css" />
	<link rel="stylesheet" href="{{$asset_path}}css/metisMenu.css" type="text/css" />
	<link rel="stylesheet" href="{{$asset_path}}css/timeline.css" type="text/css" />
	<link rel="stylesheet" href="{{$asset_path}}css/sb-admin-2.css" type="text/css" />
	<link rel="stylesheet" href="<?=$asset_path?>sweetalert/sweetalert.css" type="text/css" />
	<link rel="stylesheet" href="{{$asset_path}}css/custom.css" type="text/css" />
	@yield('custom_css')
</head>
<body>
	@yield('body')
	<script src="{{$asset_path}}js/jquery.js"></script>
	<script src="{{$asset_path}}js/jquery.slugify.js"></script>
	<script src="{{$asset_path}}js/bootstrap.js"></script>
	<script src="{{$asset_path}}js/jquery.dataTables.min.js"></script>
	<script src="{{$asset_path}}js/dataTables.bootstrap.min.js"></script>
	<script src="{{$asset_path}}js/metisMenu.js"></script>
	<script src="{{$asset_path}}js/Chart.js"></script>
	<script src="<?=$asset_path?>sweetalert/sweetalert.js"></script>
	<script src="{{$asset_path}}js/frontend.js"></script>
	<script src="{{$asset_path}}js/sb-admin-2.js"></script>
	<script src="{{$asset_path}}js/bootstrap-datepicker.min.js"></script>
	<script src="{{$asset_path}}js/common.js"></script>
	@yield('last_scripts')
</body>
</html>
