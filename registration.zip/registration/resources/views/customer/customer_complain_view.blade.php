@extends('admin.layouts.app')

@section('section')

      <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-md-6">
                        </div>
                        <div class="col-md-6">
                            <div class="btn-group pull-right">
                                <a class="btn green btn-success btn-flat"
                                   href="{{ route('customers.query') }}"
                                   title="Add new Complaint"><i class="fa fa-plus"></i> New Complaint</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel-body">
                    <table class="responsive table table-hover table-condensed order-column">
                        <thead>
                        <tr class="">
                           <th>Name</th>
                            <th>Email</th>
                            <th>Message</th>
                        </tr>
                            @foreach($customerCompalian as $data) 
                                 <tr class="">
                                    <td>{{$data->name}}</td>
                                    <td>{{$data->email}}</td>
                                    <td>{{$data->message}}</td>
                                 </tr>
                              @endforeach; 
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>

@endsection


