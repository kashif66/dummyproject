@extends('admin.layouts.app')
@section('title', 'Users > Query Form')
@section('page_heading')
    <section class="content-header">
        <h3 class="pull-left">
            Query Form
        </h3>
        <ul class="breadcrumb pull-right">
           
            <li><a href="{{ route('customers.complains_view') }}">Query Form</a></li>
            <li class="active"> Query Form</li>
        </ul>
    </section>
@endsection
@section('section')
    <div class="row">
        <div class="col-sm-12">
            {!!
                Form::open([
                    'route' => 'customers.submit_query',
                    'method' => 'post',
                    'role' => 'form',
                    'class' => 'form-vertical',
                    
                ]);
                 csrf_field()
            !!}
            <div class="panel panel-default">
                <div class="panel-heading font-bold"> &nbsp;</div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="name ">{{ __('Name') }}<span class="required">*</span></label>
                                {!! Form::text('name', null, array('required' => true, 'class' => 'form-control')) !!}
                              </div>
                        </div>
                       <div class="col-sm-3">
                            <div class="form-group">
                                <label for="email ">{{ __('Email') }}<span class="required">*</span></label>
                                {!! Form::text('email', null, array('required' => true, 'class' => 'form-control')) !!}
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-8">
                            <div class="form-group">
                                <label for="message">{{ __('Message') }}<span class="required">*</span></label>
                              {!! Form::textarea('message', null, array('required' => true, 'class' => 'form-control')) !!}
                            </div>
                        </div>
                       </div> 
                    <div class="line line-dashed b-b line-lg "></div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <input type="submit" value="{{ __('Submit') }}" class="btn green btn-primary btn-flat button">
                                <button class="btn btn-default btn-flat" name="button" type="reset">
                                    {{ __('Reset') }}
                                </button>
                                <a class="btn btn-danger btn-flat" href="{{ route('users.index') }}">
                                    <i class="fa fa-times"></i> {{ __('Cancel') }}
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {!! Form::close()  !!}
        </div>
    </div>
@endsection
