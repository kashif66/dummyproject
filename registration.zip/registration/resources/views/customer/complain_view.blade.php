@extends('admin.layouts.app')
@section('title', 'Customer Complaints  ')
@section('page_heading')
    <section class="content-header">
        <h1 class="pull-left">
             Customer Complaints
        </h1>
        <ul class="breadcrumb pull-right">
           <li class="active">Customer Complaints</li>
        </ul>
    </section>
@endsection
@section('section')

      <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-md-6">
                        </div>
                        <div class="col-md-6">
                            <div class="btn-group pull-right">
                                <a class="btn green btn-success btn-flat"
                                   href="{{ route('users.add') }}"
                                   title="Add new User"><i class="fa fa-plus"></i> New User</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel-body">
                    <table class="responsive table table-hover table-condensed order-column">
                        <thead>
                        <tr class="">
                           
                            <th>Name</th>
                            <th>Email</th>
                            <th>Message</th>
                            <th>Actions</th>
                        </tr>
                        @foreach($compalian as $data) 
                         <tr class="">
                            <td>{{$data->name}}</td>
                            <td>{{$data->email}}</td>
                            <td>{{$data->message}}</td>
                            <td> <a href= "{{ route('complains.destroy', $data->id) }}" >Delete</a>
                            </td>
                            </tr>
                          @endforeach; 
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>

@endsection
