@extends('admin.layouts.app')
@section('title', 'Customer ')
@section('page_heading')
    <section class="content-header">
        <h1 class="pull-left">
             Customer
        </h1>
        <ul class="breadcrumb pull-right">
           <li class="active">Customer</li>
        </ul>
    </section>
@endsection
@section('section')

      <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-md-6">
                        </div>
                        <div class="col-md-6">
                            <div class="btn-group pull-right">
                              
                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel-body">
                    <table class="responsive table table-hover table-condensed order-column">
                        <thead>
                        <tr class="">
                           
                            <th>Name</th>
                            <th>Country</th>
                            <th>State</th>
                            <th>Phone</th>
                            <th>Email</th>
                           <th>Actions</th>
                        </tr>
                            <td>{{$user->name}}</td>
                            <td>{{$user->country->name}}</td>
                            <td>{{$user->state->name}}</td>
                            <td>{{$user->phone}}</td>
                            <td>{{$user->email}}</td>
                            <td> <a href= "{{ route('users.edit', $user->id) }}" class="btn btn-info" >Update</a>
                                <a href= "{{ route('users.changePassword', $user->id) }}" class="btn btn-primary" >ChangePassword</a></td>
                           
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>

@endsection
