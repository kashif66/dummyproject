<?php

namespace App\Http\Controllers;

use App\Country;
use App\Http\Requests\User as UserRequest;
use App\Http\Requests\UserChangePassword;
use App\State;
use App\User;
use Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Yajra\DataTables\Facades\DataTables;

class UserController extends Controller
{
    
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('admin.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $countriesDropDownList = Country::all()->pluck('name', 'id');
        $StateDropDownList = State::all()->pluck('name', 'id');
       
        return view('admin.add', compact('countriesDropDownList', 'StateDropDownList'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(UserRequest $request)
    {
        $data = new User;
        $data->fill($request->all());
        $data->password = Hash::make($request->password);
        if ($data->save()) {
            flash()->success(__('User added successfully.'));
        } else {
            flash()->error(__('Error while adding a User.'));
        }

        return redirect()->route('users.index');
    }

     /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user = User::findOrFail($id);
         $countriesDropDownList = Country::all()->pluck('name', 'id');
        $StateDropDownList = State::all()->pluck('name', 'id');
        if (is_null($user)) {
            flash()->error( __('Invalid Request'));
            return back();
        }

       return view('admin.edit', compact('user', 'countriesDropDownList', 'StateDropDownList'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UserRequest $request, $id)
    {
       $user = User::findOrFail($id);
        $user->fill($request->all());
        if ($user->isDirty()) {
            $user->save();
            flash()->success(__('User successfully updated'));
        }

        return redirect()->route('users.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
       $user = User::findOrFail($id);
        if (is_null($user)) {
            flash()->success(__('Unauthorize request'));
            return back();
        }
        if ($user->delete()) {
            flash()->success(__('User deleted successfully!'));
        } else {
            flash()->error(__('Error! User account cannot be deleted.'));
        }

        return redirect()->route('users.index');
    }

     /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function data()
    {
        $users = User::select([ 'id', 'name','email','country_id', 'state_id', 'phone', 'created_at' ])->orderBy('id', 'DESC')->where('id' , '!=', Auth::user()->id);

        return Datatables::of($users)
            ->addColumn('created_at', function ($user) {
                return date('M d, y', strtotime($user->created_at));
            })
             ->addColumn('country_name', function ($users) {
                if (!empty($users->country->name)) {
                    return $users->country->name;
                }
            })
            ->addColumn('state_name', function ($users) {
                if (!empty($users->state->name)) {
                    return $users->state->name;
                }
            })
            ->addColumn('actions', function ($user) {
                return '<a href="' . route('users.edit', $user->id) . '" >
                <i class="fa fa-pencil"></i></i></a> &nbsp;
                <a href="' . route('users.destroy', $user->id) . '"
                onclick="if(confirm(\'Are you sure want to delete this record?\')){ return true }else{ return false }">
                <i class="fa fa-times text-danger"></i></a>';
            })
            ->rawColumns(['actions'])
            ->make(true);
    }

    /**
     * Show the form for editing the account.
     */
    public function profile()
    {
        $id = Auth::user()->id;
        $user = User::find($id);
            $countriesDropDownList = Country::all()->pluck('name', 'id');
            $StateDropDownList = State::all()->pluck('name', 'id');
        if (is_null($user)) {
            flash()->error(__('Invalid Request'));
            return back();
        }
        
        return view('admin.profile', compact('user', 'countriesDropDownList', 'StateDropDownList'));
    }

     /**
     * Show the form for password.
     */
    public function changePassword($id)
    {
        return view('admin.change_password',compact('id'));
    }

     /**
     * Update account password.
     *
     * @param  \App\Http\Requests\UserChangePassword $request
     *
     * @return \Illuminate\Http\Response
     */
    public function savePassword(UserChangePassword $request)
    {
        $id = $request->id;
        $user = User::find($id);
         if (Hash::check($request->old_password, $user->password)) { 
            $user->fill([
            'password' => Hash::make($request->password)
            ])->save();
            flash()->success(__('Password changed successfully!'));
            return back();

        } else {

            flash()->error(__('Password does not match'));
            return back();
        }
    }
    


}
