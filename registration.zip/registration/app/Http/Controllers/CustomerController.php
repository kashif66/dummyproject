<?php

namespace App\Http\Controllers;

use App\Complain;
use App\Mail\WelcomeMail;
use App\User;
use Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class CustomerController extends Controller
{
    
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $compalian = Complain::all();
        return view('customer.complain_view', compact('compalian'));
    }

    /**
     * Display a customer.
     *
     */
    public function profile()
    {
        $id = Auth::user()->id;
        $user = User::find($id);

        return view('customer.index', compact('user'));
    }

     /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function customerComplain()
    {
        $customerCompalian = Complain::where('user_id', Auth::user()->id)->get();
        return view('customer.customer_complain_view', compact('customerCompalian'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('customer.query_form');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = new Complain;
        $messageBody    = $request->message;
        $firstName    = $request->name;
        $email    = $request->email;
        $toUser = User::where('roles', 'Admin')->first();

        if (!is_null($toUser)) {
        Mail::send('emails.response', compact('request','messageBody','toUser','firstName','email'), function($message) use ($request, $messageBody, $toUser, $firstName, $email ) {
            $message->to($toUser->email)->subject
            ('Complains')->from($request->email);
            });

            $data->user_id =  Auth::user()->id;
            $data->fill($request->all());
                if ($data->save()) {
                    flash()->success(__('Complain send successfully.'));
                } else {
                    flash()->error(__('Error while adding a User.'));
                }
        }
       

        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $complain = Complain::findOrFail($id);
        if (is_null($complain)) {
            flash()->success(__('Unauthorize request'));
            return back();
        }
        if ($complain->delete()) {
            flash()->success(__('Customer Complain deleted successfully!'));
        } else {
            flash()->error(__('Error! Customer Complain account cannot be deleted.'));
        }

        return back();
    }
}
