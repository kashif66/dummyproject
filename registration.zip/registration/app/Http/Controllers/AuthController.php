<?php

namespace App\Http\Controllers;

use App\Country;
use App\State;
use Illuminate\Http\Request;

class AuthController extends Controller
{

    /**
     * Get states based on country id.
     *
     * @param  int $countyId
     *
     * @return \Illuminate\Http\Response
     */
    public function getStates(Request $request)
    {
        $countryId = $request->countyId;
       	$states = State::getStatesByCountry($countryId);

        return response()->json(['country_states' => $states]);
    }

      /**
     * Get states based on country code.
     *
     *
     * @return \Illuminate\Http\Response
     */
    public function getCode(Request $request)
    {
    	$countryId = $request->country_id;
    	$phoneCode = Country::where('id', $countryId)->first();
    	
        return response()->json(['phone_code' => $phoneCode->phone_code]);
    }
}
