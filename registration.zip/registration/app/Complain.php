<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Complain extends Model
{
    protected $guarded = [];
	protected $table = 'complains';
	public $timestamps = false;
	 /**
     * Get the User.
     */
    public function user()
    {
        return $this->belongsTo('App\User');
    }
}
