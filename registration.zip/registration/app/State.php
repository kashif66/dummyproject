<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class State extends Model
{
    protected $guarded = [];
    protected $table = 'states';

    /**
     * Get the country.
     */
     public function country()
    {
        return $this->belongsTo('App\Country');
    }

     /**
     * Get all states.
     *
     * @return \Illuminate\Http\Response
     */
    protected function getStatesList()
    {
        return $this::all()->pluck('name', 'id');
    }

    /**
     * Get states based on country id.
     *
     * @param integer countryId
     * @return \Illuminate\Http\Response
     */
    protected function getStatesByCountry($countryId)
    {
        return $this::where('country_id', $countryId)
            ->orderBy('name', 'ASC')
            ->pluck('name', 'id');
    }

   
}
