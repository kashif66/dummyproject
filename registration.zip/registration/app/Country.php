<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Country extends Model
{
 	protected $guarded = [];
	protected $table = 'countries';

	 /**
	 * Get all states.
	 *
	 * @return \Illuminate\Http\Response
	 */
	protected function getCountriesList()
    {
        return $this::all()->pluck('name', 'id');
    }

}
